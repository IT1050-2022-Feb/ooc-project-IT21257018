#pragma once
class LabReport
{
private:
	char reportID[5];
	char reportName[20];

public:
	LabReport();
	LabReport(int lrep);
	LabReport(char r_ID[], char r_Name[]);
	void DisplayReportDetails();
	~LabReport();
};


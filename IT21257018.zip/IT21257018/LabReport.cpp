#include "stdafx.h"
#include "LabReport.h"
#include <cstring>
#include <iostream>
using namespace std;


LabReport::LabReport()
{
	strcpy_s(reportID, "LR001");
	strcpy_s(reportName, "PCR Report");
}

LabReport::LabReport(int lrep)
{
}

LabReport::LabReport(char r_ID[], char r_Name[])
{
	strcpy_s(reportID, r_ID);
	strcpy_s(reportName, r_Name);
}

void LabReport::DisplayReportDetails()
{
	cout << "Lab Report ID : " << reportID << endl
		<< "Lab Report Name : " << reportName << endl;
}


LabReport::~LabReport()
{
	cout << "Destructed" << endl;
}
